Projet Android - QuotexSignalBot
--------------------------------
- Min SDK: 29 (Android 10)
- Fonction: Récupère le taux EUR/USD depuis exchangerate.host, construit des bougies 1m,
  calcule RSI(14) et affiche un signal "EN HAUT" / "EN BAS" dans l'application.
- Notifications: lorsque le signal change vers EN HAUT ou EN BAS, l'application envoie
  une notification et vibre.

Instructions:
1. Ouvrir Android Studio -> Open an existing project -> sélectionner le dossier QuotexSignalBot.
2. Gradle sync (Internet requis). Puis Run sur un appareil Android (ou émulateur).
3. Dans l'application, appuyer sur Start Service pour démarrer la collecte.

Remarques:
- Pour production/professionnel il est recommandé d'utiliser un flux tick/WS (API payante)
  au lieu de exchangerate.host qui est basique.
- Le service démarre en foreground pour éviter qu'Android le tue; l'utilisateur verra une
  notification persistante "Service actif".
