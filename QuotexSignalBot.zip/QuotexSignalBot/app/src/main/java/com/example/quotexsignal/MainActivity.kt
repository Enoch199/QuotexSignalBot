package com.example.quotexsignal

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var tvPrice: TextView
    private lateinit var tvRsi: TextView
    private lateinit var tvSignal: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val price = intent?.getDoubleExtra("price", 0.0) ?: 0.0
            val rsi = intent?.getDoubleExtra("rsi", -1.0) ?: -1.0
            val signal = intent?.getStringExtra("signal") ?: "Neutre"

            tvPrice.text = "Prix: $price"
            tvRsi.text = if (rsi >= 0) "RSI: ${"%.2f".format(rsi)}" else "RSI: --"
            tvSignal.text = "Signal: $signal"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvPrice = findViewById(R.id.tvPrice)
        tvRsi = findViewById(R.id.tvRsi)
        tvSignal = findViewById(R.id.tvSignal)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        btnStart.setOnClickListener {
            startService(Intent(this, PriceService::class.java))
        }
        btnStop.setOnClickListener {
            stopService(Intent(this, PriceService::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, IntentFilter("com.example.quotexsignal.PRICE_UPDATE"))
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
}
