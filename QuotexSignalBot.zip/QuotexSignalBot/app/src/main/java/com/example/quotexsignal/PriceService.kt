package com.example.quotexsignal

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class Candle(var open: Double, var high: Double, var low: Double, var close: Double, var startTs: Long)

class PriceService : Service() {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // list of closed candles (oldest first)
    private val closedCandles = mutableListOf<Candle>()
    private var currentCandle: Candle? = null

    // internal buffer of recent closes for RSI
    private val closes = mutableListOf<Double>()

    private var isRunning = false
    private var lastSignal: String = "Neutre"

    private val CHANNEL_ID = "quotex_signal_channel"
    private val NOTIF_ID = 1001

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Service actif", "Collecte des prix..."))
        startFetching()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopFetching()
    }

    private fun startFetching() {
        if (isRunning) return
        isRunning = true
        scope.launch {
            while (isRunning) {
                try {
                    val price = fetchEurUsd()
                    price?.let { p ->
                        updateCandle(p)
                        checkRsiAndBroadcast()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(5000) // sample every 5s
            }
        }
    }

    private fun stopFetching() {
        isRunning = false
        scope.cancel()
    }

    private fun fetchEurUsd(): Double? {
        val url = "https://api.exchangerate.host/latest?base=EUR&symbols=USD"
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val jo = JSONObject(body)
            val rates = jo.getJSONObject("rates")
            return rates.getDouble("USD")
        }
    }

    private fun updateCandle(price: Double) {
        val now = System.currentTimeMillis()
        val minuteStart = now / 60000 * 60000
        val c = currentCandle
        if (c == null || c.startTs != minuteStart) {
            // close previous candle
            currentCandle?.let {
                closedCandles.add(it)
                closes.add(it.close)
                if (closes.size > 200) closes.removeAt(0)
                if (closedCandles.size > 500) closedCandles.removeAt(0)
            }
            // start new candle
            currentCandle = Candle(price, price, price, price, minuteStart)
        } else {
            // update current
            c.high = maxOf(c.high, price)
            c.low = minOf(c.low, price)
            c.close = price
        }
    }

    private fun checkRsiAndBroadcast() {
        val localCloses = ArrayList(closes)
        currentCandle?.close?.let { if (localCloses.isEmpty() || localCloses.last() != it) localCloses.add(it) }
        val rsi = Rsi.computeRSI(localCloses, 14)
        val signal = when {
            rsi == null -> "Neutre"
            rsi < 30.0 -> "EN HAUT"
            rsi > 70.0 -> "EN BAS"
            else -> "Neutre"
        }
        // broadcast via Intent to UI
        val i = Intent("com.example.quotexsignal.PRICE_UPDATE")
        i.putExtra("price", currentCandle?.close ?: 0.0)
        i.putExtra("rsi", rsi ?: -1.0)
        i.putExtra("signal", signal)
        sendBroadcast(i)

        // if signal changed to EN HAUT / EN BAS, send notification + vibration
        if (signal != lastSignal && (signal == "EN HAUT" || signal == "EN BAS")) {
            notifySignal(signal, rsi)
            lastSignal = signal
        }
    }

    private fun notifySignal(signal: String, rsi: Double?) {
        val title = if (signal == "EN HAUT") "Signal HAUT détecté" else "Signal BAS détecté"
        val text = "EUR/USD • RSI=${rsi?.let{"%.2f".format(it)} ?: "--"}"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID + 1, buildNotification(title, text))
        // vibration
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(400)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Quotex Signal"
            val desc = "Notifications de signaux EUR/USD"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance)
            channel.description = desc
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }
}
