package com.example.quotexsignal

object Rsi {
    // closes: newest last
    fun computeRSI(closes: List<Double>, period: Int = 14): Double? {
        if (closes.size <= period) return null
        val gains = mutableListOf<Double>()
        val losses = mutableListOf<Double>()
        for (i in 1 until closes.size) {
            val diff = closes[i] - closes[i-1]
            if (diff >= 0) { gains.add(diff); losses.add(0.0) }
            else { gains.add(0.0); losses.add(-diff) }
        }
        // Use Wilder's smoothing:
        var avgGain = gains.subList(0, period).average()
        var avgLoss = losses.subList(0, period).average()
        for (i in period until gains.size) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100 - (100 / (1 + rs))
    }
}
